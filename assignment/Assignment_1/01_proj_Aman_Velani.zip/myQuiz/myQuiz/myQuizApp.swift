//
//  myQuizApp.swift
//  myQuiz
//
//  Created by Aman Velani on 1/31/24.
//

import SwiftUI

@main
struct myQuizApp: App {
    var body: some Scene {
        WindowGroup {
            myQuizView()
        }
    }
}
